  const paymentSelect = document.getElementById('paymentMethod');
    const cardDetails = document.getElementById('cardDetails');
    const paypalDiv = document.getElementById('paypalButton');
    const bankDiv = document.getElementById('bankTransfer');

    // Hide all payment options initially
    cardDetails.style.display = 'none';
    paypalDiv.style.display = 'none';
    bankDiv.style.display = 'none';

    paymentSelect.addEventListener('change', function() {
        const value = this.value;
        cardDetails.style.display = value === 'creditCard' ? 'flex' : 'none';
        paypalDiv.style.display = value === 'paypal' ? 'block' : 'none';
        bankDiv.style.display = value === 'bankTransfer' ? 'block' : 'none';
    });

document.getElementById('bookingForm').addEventListener('submit', function(e){
    e.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const checkin = document.getElementById('checkin').value;
    const checkout = document.getElementById('checkout').value;
    const guests = document.getElementById('guests').value;

    if(name && email && checkin && checkout && guests){
        document.getElementById('bookingMessage').textContent = `Thank you, ${name}! Your booking for ${guests} guest(s) from ${checkin} to ${checkout} has been received.`;
        this.reset();
    } else {
        document.getElementById('bookingMessage').textContent = "Please fill all fields.";
        document.getElementById('bookingMessage').style.color = "red";
    }
});
document.querySelectorAll('.room-card').forEach(room => {
    const images = room.querySelectorAll('.room-images img');
    let index = 0;

    if(images.length > 1) {
        images[index].classList.add('active'); // show first image

        setInterval(() => {
            images[index].classList.remove('active');
            index = (index + 1) % images.length;
            images[index].classList.add('active');
        }, 3000); // slide every 3 seconds
    }
});
